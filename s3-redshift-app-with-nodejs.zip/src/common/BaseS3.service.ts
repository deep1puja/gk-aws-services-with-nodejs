import { Injectable } from '@nestjs/common';
import { S3 } from 'aws-sdk';

@Injectable()
export class BaseS3 {
  protected readonly s3: S3;
  protected readonly BucketName = process.env.BucketName;
  constructor() {
    this.s3 = new S3({
      accessKeyId: process.env.AccessKey,
      secretAccessKey: process.env.SecretAccessKey,
      region: process.env.Region,
    });
  }
}

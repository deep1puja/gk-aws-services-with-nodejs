import { Module } from '@nestjs/common';
import { RedshiftService } from './redshift.service';
import { RedshiftController } from './redshift.controller';
import { FilesService } from 'src/files/files.service';

@Module({
  controllers: [RedshiftController],
  providers: [RedshiftService,FilesService]
})
export class RedshiftModule {}

import { Injectable } from '@nestjs/common';
import * as pgPromise from 'pg-promise';

const connections = [];
@Injectable()
export class RedshiftService {
  async getConnection() {
    const dbName = 'dev';
    if (!connections[dbName]) {
      const dbUser = process.env.dbUser;
      const dbPassword = process.env.dbPassword;
      const dbHost = process.env.dbHost;
      const dbPort = process.env.dbPort;
      const dbc = pgPromise({ capSQL: true });
      console.log(`Opening connection to: ${dbName}, host is: ${dbHost}`);
      const connectionString = `redshift://${dbUser}:${dbPassword}@${dbHost}:${dbPort}/${dbName}`;
      connections[dbName] = dbc(connectionString, { rawConnection: true });
    }
    return connections[dbName];
  }

  async setProducts(jsonData: string) {
    try {
      const connection = await this.getConnection();
      let jsonArrayData = JSON.parse(jsonData);
      let values = '';
      let count = 0;
      jsonArrayData.forEach((data) => {
        if (
          data.product_name == !undefined ||
          data.product_quantity == !undefined ||
          data.product_price == !undefined
        )
          return {
            status: 'error',
            msg: 'Invalid JSON data keyname',
            data: '',
          };
        values =
          values +
          `('${data.product_name}','${data.product_quantity}','${data.product_price}'),`;
        count++;
      });
      values = values.slice(0, -1);
      const query = `insert into product_master (product_name,product_quantity,product_price ) values ${values}`;
      return await connection
        .query(query, { raw: true })
        .then(() => {
          return {
            status: 'success',
            msg: count + ' New row(s) inserted.!!',
            data: '',
          };
        })
        .catch((error: any) => {
          return { status: 'error', msg: error.message, data: '' };
        });
    } catch (e) {
      return { status: 'error', msg: e, data: '' };
    }
  }

  async getProducts() {
    try {
      const connection = await this.getConnection();
      return await connection
        .query('select * from product_master', { raw: true })
        .then((tableResult: any) => {
          return { status: 'success', msg: '', data: tableResult };
        })
        .catch((error: any) => {
          return { status: 'error', msg: error.message, data: '' };
        });
    } catch (e) {
      return { status: 'error', msg: e, data: '' };
    }
  }
}

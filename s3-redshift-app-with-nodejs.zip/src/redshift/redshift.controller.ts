import { Controller, Get, Query } from '@nestjs/common';
import { RedshiftService } from './redshift.service';
import { FilesService } from '../files/files.service';

@Controller('redshift')
export class RedshiftController {
  constructor(
    private readonly redshiftService: RedshiftService,
    private readonly appService: FilesService,
  ) {}

  @Get('set-product-from-s3-json')
  async setproduct(@Query() query) {
    const s3response = await this.appService.getJsonFileFromS3ByKeyName(
      query.keyName,
    );

    if (s3response.status === 'success') {
      const response = await this.redshiftService.setProducts(s3response.data);
      return { response };
    } else {
      return { s3response };
    }
  }
  @Get('getproduct')
  async getproduct() {
    let response = await this.redshiftService.getProducts();

    return { response };
  }
}

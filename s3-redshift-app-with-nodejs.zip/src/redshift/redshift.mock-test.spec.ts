import { Test, TestingModule } from '@nestjs/testing';
import { RedshiftController } from './redshift.controller';
import { RedshiftService } from './redshift.service';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { FilesService } from '../files/files.service';

describe('RedshiftController', () => {
  let controller: RedshiftController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [ConfigModule.forRoot({ isGlobal: true, envFilePath: '.env' })],
      controllers: [RedshiftController],
      providers: [RedshiftService,ConfigService,FilesService],
    }).compile();

    controller = module.get<RedshiftController>(RedshiftController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  const successResponse = {
    response: {
      data: '',
      msg: '6 New row(s) inserted.!!',
      status: 'success',
    },
  };
  const errorResponse = {
    s3response: {
      data: "",
      msg: "The specified key does not exist.",
      status: "error",
    },
  };
  
  const mS3Instance = { 
    promise: jest.fn(),
    setProduct: jest.fn().mockReturnThis(),
  };
  describe('MOCK - Redsift move data from S3 json file', () => {
    it('should get correctly', async () => {
      mS3Instance.setProduct.mockReturnValueOnce(successResponse);
      expect(
        mS3Instance.setProduct({
          keyName: 'products.json',
        }),
      ).toEqual(successResponse);
    });

    it('should not get correctly', async () => {
      mS3Instance.setProduct.mockReturnValueOnce(errorResponse);
      expect(
        mS3Instance.setProduct({
          keyName: 'test.json',
        }),
      ).toEqual(errorResponse);
    });
  });
 
});

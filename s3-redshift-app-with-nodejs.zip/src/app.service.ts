import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
@Injectable()
export class AppService {
  welCome(): string {
    return 'Welcome..!';
  }
}

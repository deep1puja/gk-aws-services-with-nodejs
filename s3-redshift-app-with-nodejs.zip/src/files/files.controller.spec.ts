import { Test, TestingModule } from '@nestjs/testing';
import { FilesController } from './files.controller';
import { FilesService } from './files.service';
import { ConfigModule, ConfigService } from '@nestjs/config';

import { BaseS3 } from '../common/BaseS3.service';
describe('FilesController', () => {
  let filesController: FilesController;

  beforeEach(async () => {
    const files: TestingModule = await Test.createTestingModule({
      imports: [ConfigModule.forRoot({ isGlobal: true, envFilePath: '.env' })],
      controllers: [FilesController],
      providers: [FilesService, ConfigService, BaseS3],
    }).compile();

    filesController = files.get<FilesController>(FilesController);
  });
  const successResponse = {
    response: {
      data: {
        file: '{"name":"GULSHAN KUMAR","email":"gulshan.kumar6@ibm.com"}',
        fileSize: '0.06 KB',
        fileType: 'application/json',
      },
      msg: '',
      status: 'success',
    },
  };
  const errorResponse = {
    response: {
      data: '',
      msg: 'The specified key does not exist.',
      status: 'error',
    },
  };

  describe('S3 Service - get object by keyName', () => {
    it('should return  "gk.json" file details', async () => {
      let response = await filesController.getFileFromS3({
        keyName: 'gk.json',
      });
      expect(response).toEqual(successResponse);
    });

    it('should return  error', async () => {
      let response = await filesController.getFileFromS3({
        keyName: 'xyz.jnon',
      });
      expect(response).toEqual(errorResponse);
    });
  });

  const mS3Instance = {
    upload: jest.fn().mockReturnThis(),
    promise: jest.fn(),
    getFileFromS3: jest.fn().mockReturnThis(),
  };

  jest.mock('aws-sdk', () => {
    return { S3: jest.fn(() => mS3Instance) };
  });

  describe('S3 MOCK Testing by JEST-Mock', () => {
    it('should get correctly', async () => {
      mS3Instance.getFileFromS3.mockReturnValueOnce(successResponse);
      expect(
        mS3Instance.getFileFromS3({
          keyName: 'gk.json',
        }),
      ).toEqual(successResponse);
    });

    it('should not get correctly', async () => {
      mS3Instance.getFileFromS3.mockReturnValueOnce(errorResponse);
      expect(
        mS3Instance.getFileFromS3({
          keyName: 'abc.png',
        }),
      ).toEqual(errorResponse);
    });
  });
});

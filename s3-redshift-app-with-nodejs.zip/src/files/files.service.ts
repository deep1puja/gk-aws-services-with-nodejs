import { Injectable } from '@nestjs/common';
import { BaseS3 } from '../common/BaseS3.service'; 

@Injectable()
export class FilesService extends BaseS3 {
  constructor() {
    super();
  }

  async getJsonFileFromS3ByKeyName(keyName: string) {
    return await this.s3
      .getObject({ Bucket: this.BucketName, Key: keyName })
      .promise()
      .then((data) => {
          const fileData =
          data.ContentType === 'application/json'
            ? data.Body.toString()
            : data.Body.toString('base64');
            return { status: 'success', msg: '', data:fileData };
        
      })
      .catch((error) => {
        return { status: 'error', msg: error.message, data: '' };
      });
  }

  async getFileFromS3(keyName: string) {
    return await this.s3
      .getObject({ Bucket: this.BucketName, Key: keyName })
      .promise()
      .then((data) => {
        const fileData =
          data.ContentType === 'application/json'
            ? data.Body.toString()
            : data.Body.toString('base64');
        return {
          status: 'success',
          msg: '',
          data: {
            file: fileData,
            fileSize: Number(data.ContentLength / 1024).toFixed(2) + ' KB',
            fileType: data.ContentType,
          },
        };
      })
      .catch((error) => {
        return { status: 'error', msg: error.message, data: '' };
      });
  }

  async listFiles() {
    const params = {
      Bucket: this.BucketName,
      Delimiter: '',
      Prefix: '',
    };

    return await this.s3
      .listObjects(params)
      .promise()
      .then((listObjects) => {
        let allListObjects = [];
        for (let index = 0; index < listObjects['Contents'].length; index++) {
          allListObjects.push({
            name: listObjects['Contents'][index]['Key'],
            url: process.env.s3BaseURL + listObjects['Contents'][index]['Key'],
          });
        }
        return { status: 'success', msg: '', data: allListObjects };
      })
      .catch((error) => {
        return { status: 'error', msg: error.message, data: '' };
      });
  }

  async uploadFile(file) {
    let s3Params = {
      Bucket: this.BucketName,
      Key: 'img/' + file.originalname,
      ACL: 'public-read',
      ContentType: file.mimetype,
      Body: file.buffer,
    };
    return this.s3
      .putObject(s3Params)
      .promise()
      .then(() => {
        return { status: 'success', msg: 'New file uploaded..!', data: '' };
      })
      .catch((error) => {
        return { status: 'error', msg: error.message, data: '' };
      });
  }
}

import {
  Controller,
  Get,
  Post,
  Query,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FilesService } from './files.service';
import { FileInterceptor } from '@nestjs/platform-express'; 
@Controller('files')
export class FilesController {
  constructor(private readonly appService: FilesService) {}
  
  // @Get('redshift/set-product-from-s3-json')
  // async setproduct(@Query() query) {
  
  //   let s3response = await this.appService.getJsonFileFromS3ByKeyName(query.keyName);
  //   //console.log("===response2.data===", ((JSON.stringify(response2.data)).replace(/\\n/g, '')));
  //   // console.log("===response1===",response2.data);
  //   // console.log("===response1===",JSON.parse((response2.data)));
    
  //    if(s3response.status==='success'){
  //     let response = await RedshiftClass.setProducts(s3response.data);
  //     return { response};
  //    }else{
  //     return { s3response };
  //    }
    
   

  // }
  // @Get('redshift/getproduct')
  // async getproduct(@Query() query) {
  
  //   let response = await RedshiftClass.getProducts();
   
  //   return { response };

  // }

  @Get()
  async getFileFromS3(@Query() query) {
    let response = await this.appService.getFileFromS3(query.keyName);

    return { response };
  }

  @Get('list')
  async listFiles(@Query() query) {

    let response = await this.appService.listFiles();

    return { response };
  }

  @Post('upload')
  @UseInterceptors(FileInterceptor('file'))
  async uploadFile(@UploadedFile() file: Express.Multer.File) {
    console.log(file);
    let response = await this.appService.uploadFile(file);
    return { response };
  }
}

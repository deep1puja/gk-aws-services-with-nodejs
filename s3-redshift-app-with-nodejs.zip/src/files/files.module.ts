import { Module } from '@nestjs/common';
import { FilesController } from './files.controller';
import { FilesService } from './files.service';  
import { ConfigModule } from '@nestjs/config';
import { BaseS3 } from '../common/BaseS3.service';

@Module({
  imports:  [ConfigModule.forRoot({ isGlobal: true, envFilePath :'.env'})],
  controllers: [FilesController],
  providers: [FilesService,BaseS3],
})
export class FilesModule { }

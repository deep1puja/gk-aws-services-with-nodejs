import {
  GetObjectCommand,
  S3Client,
  UploadPartCommand,
} from '@aws-sdk/client-s3';
import { sdkStreamMixin } from '@aws-sdk/util-stream-node';
import { mockClient } from 'aws-sdk-client-mock';
import { Readable } from 'stream';
const s3Mock = mockClient(S3Client);

s3Mock.on(UploadPartCommand).rejects();
it('Mocks get object from S3', async () => {
  // create Stream from string
  const stream = new Readable();
  stream.push('hello world');
  stream.push(null);
  const sdkStream = sdkStreamMixin(stream);

  s3Mock.on(GetObjectCommand).resolves({ Body: sdkStream });

  const s3 = new S3Client({});

  const getObjectResult = await s3.send(
    new GetObjectCommand({ Bucket: 'testBacket', Key: 'test.txt' }),
  );

  const str = await getObjectResult.Body?.transformToString();

  expect(str).toBe('hello world');
});

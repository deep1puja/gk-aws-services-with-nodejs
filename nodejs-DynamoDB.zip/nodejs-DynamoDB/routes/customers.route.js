const customersModule = require('../controller/customer.controller');
module.exports=(app)=>{

    app.get('/all',  customersModule.getAllCustomersController)
 
    app.post('/', customersModule.newCustomersController)
}
 

const express = require('express');
const router = express.Router();
const app = express();
const port= process.env.PORT || 5000;
app.use(express.json());
app.use('/customer', router);
app.get('/',(req,res)=>{

    res.send("Welcome...!!")
});
app.listen(port,()=>{
    console.log('Welcome');
});
require('./routes/customers.route')(router);
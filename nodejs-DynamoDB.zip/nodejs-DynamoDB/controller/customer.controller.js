const AWS = require("aws-sdk");
AWS.config.update({
  region: "eu-north-1",
});

const dynamodb = new AWS.DynamoDB.DocumentClient();
const dynamodbTableName = "customers";
module.exports = {
getAllCustomersController:  async (req, res) => {
    try {
      const params = {
        TableName: dynamodbTableName,
        //  Key: 'customer_id'
      };
      const allCustomers = await scanTableRecords(params, []);
      const body = {
        customers: allCustomers,
      };
      res.json(body);
    } catch (err) {
      res.status(404).send(err);
    }
  },

newCustomersController: async (req, res) => {
    const params = {
      TableName: dynamodbTableName,
      Item: req.body,
    };
    await dynamodb
      .put(params)
      .promise()
      .then(() => {
        const body = {
          status: "sucess",
          msg: "Successfully saved..!",
        };
        res.json(body);
      })
      .catch((err) => {
        res.status(404).send(err);
      });
  }

 };

 async function scanTableRecords(scanParams,itemArray){
 
    try{
      let tableData=  await dynamodb.scan(scanParams).promise()
        itemArray = itemArray.concat(tableData.Items);
        if (tableData.LastEvaluatedKey)
        {
            scanParams.ExclusiveStartKey = tableData.LastEvaluatedKey;
          return  await scanTableRecords(scanParams, itemArray);
        } 
        return itemArray;
    } catch(error){
        throw new Error(error);
    }
}